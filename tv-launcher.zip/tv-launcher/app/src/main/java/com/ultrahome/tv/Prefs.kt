package com.ultrahome.tv

import android.content.Context

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

/** Small settings that are not about the clock. */
object UiPrefs {
    private fun p(c: Context) = c.getSharedPreferences("ui", Context.MODE_PRIVATE)

    fun look(c: Context): Int = p(c).getInt("look", 0).coerceIn(0, Backdrops.NAMES.size - 1)
    fun setLook(c: Context, v: Int) { p(c).edit().putInt("look", v).apply() }

    fun favorites(c: Context): List<String> {
        val s = p(c).getString("fav", "") ?: ""
        return if (s.isEmpty()) emptyList() else s.split(",")
    }

    /** Returns true when the app was added, false when it was removed. */
    fun toggleFavorite(c: Context, pkg: String): Boolean {
        val l = favorites(c).toMutableList()
        val added = if (l.contains(pkg)) { l.remove(pkg); false } else { l.add(pkg); true }
        p(c).edit().putString("fav", l.joinToString(",")).apply()
        return added
    }

    fun hasChosenFavorites(c: Context): Boolean = p(c).contains("fav")
}
