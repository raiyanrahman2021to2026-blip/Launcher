package com.ultrahome.tv

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** Big rounded banner. LEFT/RIGHT: previous/next. OK: play the trailer. */
class HeroView(
    context: Context,
    private val store: SlideStore,
    private val emptyText: String
) : View(context) {

    var onPlay: ((Slide) -> Unit)? = null

    private var slides: List<Slide> = emptyList()
    private var index = 0
    private var lastKey = 0L
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val ui = Handler(Looper.getMainLooper())
    private val titleFace = Typeface.create("sans-serif-condensed", Typeface.BOLD_ITALIC)
    private val bodyFace = Typeface.create("sans-serif-light", Typeface.NORMAL)
    private val medFace = Typeface.create("sans-serif-medium", Typeface.NORMAL)

    init {
        isFocusable = true
        isFocusableInTouchMode = true
    }

    private val rotate = object : Runnable {
        override fun run() {
            if (isShown && slides.size > 1 && System.currentTimeMillis() - lastKey > 15000L) {
                index = (index + 1) % slides.size
                invalidate()
            }
            ui.postDelayed(this, 7000L)
        }
    }

    fun setSlides(list: List<Slide>) {
        slides = list
        if (index >= list.size) index = 0
        invalidate()
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        ui.removeCallbacks(rotate)
        if (visibility == VISIBLE) ui.postDelayed(rotate, 7000L)
    }

    override fun onDetachedFromWindow() {
        ui.removeCallbacks(rotate)
        super.onDetachedFromWindow()
    }

    override fun onFocusChanged(gainFocus: Boolean, direction: Int, previouslyFocusedRect: android.graphics.Rect?) {
        super.onFocusChanged(gainFocus, direction, previouslyFocusedRect)
        invalidate()
    }

    private fun step(d: Int) {
        if (slides.isEmpty()) return
        index = (index + d + slides.size) % slides.size
        lastKey = System.currentTimeMillis()
        invalidate()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_DPAD_LEFT -> { step(-1); return true }
            KeyEvent.KEYCODE_DPAD_RIGHT -> { step(1); return true }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER -> {
                slides.getOrNull(index)?.let { onPlay?.invoke(it) }
                return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun text(
        c: Canvas, s: String, x: Float, y: Float, size: Float, color: Int, tf: Typeface,
        align: Paint.Align = Paint.Align.LEFT, spacing: Float = 0f
    ) {
        paint.shader = null
        paint.style = Paint.Style.FILL
        paint.textSize = size
        paint.color = color
        paint.typeface = tf
        paint.textAlign = align
        paint.letterSpacing = spacing
        c.drawText(s, x, y, paint)
        paint.letterSpacing = 0f
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val r = h * 0.05f
        path.reset()
        path.addRoundRect(RectF(0f, 0f, w, h), r, r, Path.Direction.CW)
        c.save()
        c.clipPath(path)
        c.drawColor(Color.rgb(8, 9, 14))

        val s = slides.getOrNull(index)
        if (s == null) {
            text(c, emptyText, w / 2f, h / 2f, h * 0.05f, Color.argb(190, 255, 255, 255), bodyFace, Paint.Align.CENTER)
            c.restore()
            return
        }

        val bmp = if (s.hasImage) ImageCache.hero(s.id) else null
        if (bmp != null) drawCover(c, bmp, w, h) else drawArt(c, s.accent, w, h)
        if (s.hasImage && bmp == null) ImageCache.heroAsync(store, s.id) { invalidate() }
        slides.getOrNull((index + 1) % slides.size)?.let { nx ->
            if (nx.hasImage) ImageCache.heroAsync(store, nx.id) { }
        }

        paint.style = Paint.Style.FILL
        paint.shader = LinearGradient(
            0f, 0f, 0f, h,
            intArrayOf(Color.argb(70, 0, 0, 0), Color.argb(0, 0, 0, 0), Color.argb(225, 5, 6, 10), Color.rgb(5, 6, 10)),
            floatArrayOf(0f, 0.3f, 0.86f, 1f), Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, w, h, paint)
        paint.shader = null

        val left = w * 0.04f
        var titleSize = min(w * 0.07f, h * 0.17f)
        paint.typeface = titleFace
        paint.textSize = titleSize
        val maxW = w * 0.58f
        val tw = paint.measureText(s.title.uppercase())
        if (tw > maxW) titleSize *= maxW / tw

        val pillH = h * 0.105f
        val pillBottom = h * 0.90f
        val pillTop = pillBottom - pillH
        val tagY = pillTop - h * 0.035f
        val titleY = tagY - h * 0.075f
        val kickY = titleY - titleSize * 0.95f

        val kick = if (s.kicker.isNotEmpty()) s.kicker else if (s.cat == "movie") "Movie" else "Anime"
        text(c, kick.uppercase(), left, kickY, h * 0.032f, Color.argb(215, 255, 255, 255), medFace, spacing = 0.2f)

        paint.shader = null
        paint.typeface = titleFace
        paint.textSize = titleSize
        paint.textAlign = Paint.Align.LEFT
        paint.style = Paint.Style.STROKE
        paint.strokeJoin = Paint.Join.ROUND
        paint.strokeWidth = titleSize * 0.07f
        paint.color = s.accent
        c.drawText(s.title.uppercase(), left, titleY, paint)
        paint.style = Paint.Style.FILL
        paint.color = Color.WHITE
        c.drawText(s.title.uppercase(), left, titleY, paint)

        if (s.tagline.isNotEmpty()) {
            text(c, s.tagline, left, tagY, h * 0.04f, Color.argb(230, 255, 255, 255), bodyFace)
        }

        val label = "▶  Play trailer"
        paint.typeface = medFace
        paint.textSize = pillH * 0.42f
        val pw = paint.measureText(label) + pillH * 1.1f
        val rect = RectF(left, pillTop, left + pw, pillBottom)
        paint.style = Paint.Style.FILL
        paint.color = s.accent
        c.drawRoundRect(rect, pillH / 2f, pillH / 2f, paint)
        if (isFocused) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = pillH * 0.09f
            paint.color = Color.WHITE
            c.drawRoundRect(rect, pillH / 2f, pillH / 2f, paint)
        }
        text(c, label, left + pw / 2f, pillTop + pillH * 0.64f, pillH * 0.42f, Color.rgb(10, 10, 14), medFace, Paint.Align.CENTER)

        val n = slides.size
        if (n > 1) {
            val gap = w * 0.02f
            for (i in 0 until n) {
                val x = w * 0.96f - (n - 1 - i) * gap
                paint.style = Paint.Style.FILL
                paint.color = if (i == index) Color.WHITE else Color.argb(90, 255, 255, 255)
                c.drawCircle(x, pillBottom - pillH / 2f, if (i == index) w * 0.0065f else w * 0.0045f, paint)
            }
        }
        if (isFocused) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = h * 0.012f
            paint.color = Color.argb(150, 255, 255, 255)
            c.drawPath(path, paint)
        }
        c.restore()
    }

    private fun drawCover(c: Canvas, b: Bitmap, w: Float, h: Float) {
        val scale = max(w / b.width, h / b.height)
        val m = Matrix()
        m.postScale(scale, scale)
        m.postTranslate((w - b.width * scale) / 2f, (h - b.height * scale) / 2f)
        paint.shader = null
        paint.style = Paint.Style.FILL
        c.drawBitmap(b, m, paint)
    }

    /** Original artwork shown when a banner has no picture. */
    private fun drawArt(c: Canvas, accent: Int, w: Float, h: Float) {
        val dark = Color.rgb(Color.red(accent) / 6, Color.green(accent) / 6, Color.blue(accent) / 6)
        paint.style = Paint.Style.FILL
        paint.shader = LinearGradient(0f, 0f, w, h, dark, Color.rgb(8, 8, 14), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, paint)
        val cx = w * 0.72f
        val cy = h * 0.46f
        paint.shader = null
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = w * 0.004f
        for (i in 0 until 48) {
            val a = Math.toRadians(i * 7.5)
            paint.color = Color.argb(if (i % 2 == 0) 70 else 35, Color.red(accent), Color.green(accent), Color.blue(accent))
            c.drawLine(cx, cy, cx + w * cos(a).toFloat(), cy + w * sin(a).toFloat(), paint)
        }
        paint.style = Paint.Style.FILL
        paint.shader = RadialGradient(
            cx, cy, w * 0.42f,
            intArrayOf(Color.argb(255, 255, 255, 255), accent, Color.argb(0, Color.red(accent), Color.green(accent), Color.blue(accent))),
            floatArrayOf(0f, 0.22f, 1f), Shader.TileMode.CLAMP
        )
        c.drawCircle(cx, cy, w * 0.42f, paint)
        paint.shader = null
    }
}
