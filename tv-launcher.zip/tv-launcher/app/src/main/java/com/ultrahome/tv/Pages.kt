package com.ultrahome.tv

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.util.TypedValue
import android.view.View
import android.view.ViewGroup
import android.widget.AbsListView
import android.widget.BaseAdapter
import android.widget.GridView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** What the pages need from the activity. */
interface Host {
    val store: SlideStore
    val apps: List<AppEntry>
    fun favorites(): List<AppEntry>
    fun launch(intent: Intent)
    fun playTrailer(s: Slide)
    fun openTab(i: Int)
    fun editorHint(): String
    fun applyLook()
    fun showStandBy()
    fun changed()
}

interface Page {
    val view: View
    fun onShow() {}
    fun onHide() {}
    fun refresh() {}
    fun firstFocus(): View?
}

private class Metrics(ctx: Context) {
    val sw = ctx.resources.displayMetrics.widthPixels
    val sh = ctx.resources.displayMetrics.heightPixels
    val side = (sw * 0.035f).toInt()
}

private fun label(ctx: Context, text: String, px: Float, alpha: Int = 255): TextView =
    TextView(ctx).apply {
        this.text = text
        setTextSize(TypedValue.COMPLEX_UNIT_PX, px)
        setTextColor(Color.argb(alpha, 255, 255, 255))
    }

private fun lp(w: Int, h: Int, l: Int = 0, t: Int = 0, r: Int = 0, b: Int = 0) =
    LinearLayout.LayoutParams(w, h).apply { setMargins(l, t, r, b) }

// ============================================================================ HOME

class HomePage(private val ctx: Context, private val h: Host) : Page {
    private val m = Metrics(ctx)
    private val pm = ctx.packageManager
    private val scroll = ScrollView(ctx)
    private val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
    private val hero = HeroView(ctx, h.store, "Add anime and movies from your phone (see Settings)")
    private val appsRow = HRow(ctx)
    private val animeRow = HRow(ctx)
    private val movieRow = HRow(ctx)
    override val view: View get() = scroll

    private val cardW = (m.sh * 0.30f).toInt()
    private val cardH = (m.sh * 0.17f).toInt()
    private val tile = (m.sh * 0.15f).toInt()
    private val gap = (m.sh * 0.02f).toInt()

    init {
        scroll.isVerticalScrollBarEnabled = false
        scroll.isSmoothScrollingEnabled = true
        scroll.clipToPadding = false
        scroll.addView(col, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        hero.onPlay = { s -> h.playTrailer(s) }
        col.addView(hero, lp(ViewGroup.LayoutParams.MATCH_PARENT, (m.sh * 0.58f).toInt(), m.side, 0, m.side, 0))

        val titlePx = m.sh * 0.03f
        for ((name, row, rowH) in listOf(
            Triple("My apps", appsRow, tile + gap * 2),
            Triple("Anime", animeRow, cardH + gap * 2),
            Triple("Movies", movieRow, cardH + gap * 2)
        )) {
            col.addView(label(ctx, name, titlePx, 235), lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, m.side, gap * 2, 0, 0))
            row.setPadding(m.side, gap, m.side, gap)
            col.addView(row, lp(ViewGroup.LayoutParams.MATCH_PARENT, rowH))
        }
        col.setPadding(0, 0, 0, gap * 3)
    }

    override fun onShow() = rebuild()
    override fun refresh() = rebuild()

    override fun firstFocus(): View? = hero

    private fun rebuild() {
        val all = h.store.list()
        hero.setSlides(all)

        appsRow.clear()
        for (e in h.favorites()) {
            val t = AppTile(ctx, pm, true).apply {
                entry = e
                setOnClickListener { h.launch(e.intent) }
                setOnLongClickListener { UiPrefs.toggleFavorite(ctx, e.pkg); h.changed(); true }
            }
            appsRow.add(t, tile, tile, gap)
        }
        appsRow.add(CardView(ctx, h.store, null, "Add apps").apply { setOnClickListener { h.openTab(1) } }, cardW, tile, gap)

        fill(animeRow, all.filter { it.cat == "anime" }, "Add anime")
        fill(movieRow, all.filter { it.cat == "movie" }, "Add movies")
    }

    private fun fill(row: HRow, list: List<Slide>, addLabel: String) {
        row.clear()
        for (s in list) {
            row.add(CardView(ctx, h.store, s, s.title).apply { setOnClickListener { h.playTrailer(s) } }, cardW, cardH, gap)
        }
        row.add(CardView(ctx, h.store, null, addLabel).apply {
            setOnClickListener { Toast.makeText(ctx, h.editorHint(), Toast.LENGTH_LONG).show() }
        }, cardW, cardH, gap)
    }
}

// ============================================================================ ANIME / MOVIES

class ContentPage(
    private val ctx: Context,
    private val h: Host,
    private val cat: String,
    private val nice: String
) : Page {
    private val m = Metrics(ctx)
    private val root = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
    private val hero = HeroView(ctx, h.store, "No $nice yet. Add some from your phone.")
    private val row = HRow(ctx)
    private val hint = label(ctx, "", m.sh * 0.024f, 190)
    override val view: View get() = root

    private val cardW = (m.sh * 0.30f).toInt()
    private val cardH = (m.sh * 0.17f).toInt()
    private val gap = (m.sh * 0.02f).toInt()

    init {
        hero.onPlay = { s -> h.playTrailer(s) }
        root.addView(hero, lp(ViewGroup.LayoutParams.MATCH_PARENT, 0, m.side, 0, m.side, 0).apply { weight = 1f })
        row.setPadding(m.side, gap, m.side, gap)
        root.addView(row, lp(ViewGroup.LayoutParams.MATCH_PARENT, cardH + gap * 2, 0, gap, 0, 0))
        root.addView(hint, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, m.side, 0, 0, gap))
    }

    override fun onShow() = rebuild()
    override fun refresh() = rebuild()
    override fun firstFocus(): View? = hero

    private fun rebuild() {
        val list = h.store.list().filter { it.cat == cat }
        hero.setSlides(list)
        row.clear()
        for (s in list) {
            row.add(CardView(ctx, h.store, s, s.title).apply { setOnClickListener { h.playTrailer(s) } }, cardW, cardH, gap)
        }
        row.add(CardView(ctx, h.store, null, "Add $nice").apply {
            setOnClickListener { Toast.makeText(ctx, h.editorHint(), Toast.LENGTH_LONG).show() }
        }, cardW, cardH, gap)
        hint.text = "Add or change $nice from your phone:  " + h.editorHint()
    }
}

// ============================================================================ APPS

class AppsPage(private val ctx: Context, private val h: Host) : Page {
    private val m = Metrics(ctx)
    private val pm = ctx.packageManager
    private val root = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
    private val grid = GridView(ctx)
    override val view: View get() = root

    private val itemH = (m.sh * 0.19f).toInt()

    init {
        val hint = label(ctx, "OK opens an app.  Hold OK to add it to (or remove it from) Home.  ★ = shown on Home", m.sh * 0.024f, 200)
        root.addView(hint, lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, m.side, 0, 0, m.sh / 70))

        grid.numColumns = 6
        grid.horizontalSpacing = m.sh / 60
        grid.verticalSpacing = m.sh / 60
        grid.clipToPadding = false
        grid.setPadding(m.side, m.sh / 80, m.side, m.sh / 20)
        grid.isVerticalScrollBarEnabled = false
        grid.selector = android.graphics.drawable.GradientDrawable().apply {
            setColor(Color.argb(60, 255, 255, 255))
            cornerRadius = m.sh * 0.02f
            setStroke(3, Color.WHITE)
        }
        grid.setOnItemClickListener { _, _, pos, _ -> h.apps.getOrNull(pos)?.let { h.launch(it.intent) } }
        grid.setOnItemLongClickListener { _, _, pos, _ ->
            h.apps.getOrNull(pos)?.let {
                UiPrefs.toggleFavorite(ctx, it.pkg)
                (grid.adapter as? BaseAdapter)?.notifyDataSetChanged()
            }
            true
        }
        grid.adapter = object : BaseAdapter() {
            override fun getCount() = h.apps.size
            override fun getItem(position: Int): Any = h.apps[position]
            override fun getItemId(position: Int): Long = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val t = (convertView as? AppTile) ?: AppTile(ctx, pm, false).apply {
                    layoutParams = AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, itemH)
                }
                val e = h.apps[position]
                t.entry = e
                t.fav = UiPrefs.favorites(ctx).contains(e.pkg)
                t.invalidate()
                return t
            }
        }
        root.addView(grid, lp(ViewGroup.LayoutParams.MATCH_PARENT, 0).apply { weight = 1f })
    }

    override fun onShow() { (grid.adapter as? BaseAdapter)?.notifyDataSetChanged() }
    override fun refresh() { (grid.adapter as? BaseAdapter)?.notifyDataSetChanged() }
    override fun firstFocus(): View? = grid
}

// ============================================================================ SETTINGS

class SettingsPage(private val ctx: Context, private val h: Host) : Page {
    private val m = Metrics(ctx)
    private val scroll = ScrollView(ctx)
    private val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
    private val rows = ArrayList<SettingRow>()
    override val view: View get() = scroll

    private fun cfg() = ClockPrefs.read(ctx)
    private fun upd(f: (Cfg) -> Cfg) = ClockPrefs.write(ctx, f(cfg()))
    private fun onOff(b: Boolean) = if (b) "On" else "Off"

    init {
        scroll.isVerticalScrollBarEnabled = false
        scroll.clipToPadding = false
        scroll.addView(col, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        col.setPadding((m.sw * 0.18f).toInt(), 0, (m.sw * 0.18f).toInt(), m.sh / 10)

        val px = m.sh * 0.03f
        val gap = m.sh / 90

        fun header(t: String) = col.addView(label(ctx, t, px * 0.9f, 170),
            lp(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, m.sh / 40, 0, gap))
        fun row(title: String, value: () -> String, action: () -> Unit) {
            val r = SettingRow(ctx, title, value, action, px)
            rows.add(r)
            col.addView(r, lp(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 0, 0, gap))
        }

        header("STANDBY CLOCK  (shows on Home after you stop using the remote)")
        row("Style", { ClockPrefs.STYLES[cfg().style] }) { upd { it.copy(style = (it.style + 1) % ClockPrefs.STYLES.size, night = false) } }
        row("Colour", { ClockPrefs.COLOR_NAMES[cfg().color] }) { upd { it.copy(color = (it.color + 1) % ClockPrefs.COLORS.size, night = false) } }
        row("Time format", { if (cfg().h24) "24-hour" else "12-hour" }) { upd { it.copy(h24 = !it.h24) } }
        row("Seconds", { onOff(cfg().seconds) }) { upd { it.copy(seconds = !it.seconds) } }
        row("Night mode (red)", { onOff(cfg().night) }) { upd { it.copy(night = !it.night) } }
        row("Start after", {
            val v = cfg().idle
            if (v == 0) "Off" else "$v min"
        }) {
            val opts = ClockPrefs.IDLE_OPTIONS
            val i = opts.indexOf(cfg().idle)
            upd { it.copy(idle = opts[(i + 1) % opts.size]) }
        }
        row("Preview now", { "Press OK" }) { h.showStandBy() }

        header("LOOK")
        row("Background", { Backdrops.NAMES[UiPrefs.look(ctx)] }) {
            UiPrefs.setLook(ctx, (UiPrefs.look(ctx) + 1) % Backdrops.NAMES.size)
            h.applyLook()
        }

        header("ANIME AND MOVIE BANNERS")
        row("Edit from your phone", { h.editorHint() }) {
            Toast.makeText(ctx, h.editorHint(), Toast.LENGTH_LONG).show()
        }
        row("Reset banners", { "Press OK" }) {
            h.store.reset()
            h.changed()
            Toast.makeText(ctx, "Banners reset", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onShow() { rows.forEach { it.refresh() } }
    override fun refresh() { rows.forEach { it.refresh() } }
    override fun firstFocus(): View? = rows.firstOrNull()
}
