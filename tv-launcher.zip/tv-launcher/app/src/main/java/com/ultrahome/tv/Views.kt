package com.ultrahome.tv

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView

class AppEntry(val label: String, val pkg: String, val intent: Intent, val ri: ResolveInfo)

private fun scaleOnFocus(v: View, focused: Boolean) {
    val s = if (focused) 1.08f else 1f
    v.animate().scaleX(s).scaleY(s).setDuration(120).start()
}

/** Landscape card for an anime/movie, or a "+" card when [slide] is null. */
class CardView(
    context: Context,
    private val store: SlideStore,
    private val slide: Slide?,
    private val label: String
) : View(context) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val face = Typeface.create("sans-serif-medium", Typeface.NORMAL)

    init {
        isFocusable = true
        isClickable = true
    }

    override fun onFocusChanged(gainFocus: Boolean, direction: Int, previouslyFocusedRect: Rect?) {
        super.onFocusChanged(gainFocus, direction, previouslyFocusedRect)
        scaleOnFocus(this, gainFocus)
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val r = h * 0.09f
        path.reset()
        path.addRoundRect(RectF(0f, 0f, w, h), r, r, Path.Direction.CW)
        c.save()
        c.clipPath(path)

        val accent = slide?.accent ?: Color.rgb(120, 130, 160)
        val bmp: Bitmap? = if (slide != null && slide.hasImage) ImageCache.thumb(store, slide.id) else null
        paint.style = Paint.Style.FILL
        if (bmp != null) {
            val sc = maxOf(w / bmp.width, h / bmp.height)
            val dw = bmp.width * sc
            val dh = bmp.height * sc
            c.drawBitmap(bmp, null, RectF((w - dw) / 2f, (h - dh) / 2f, (w + dw) / 2f, (h + dh) / 2f), paint)
        } else {
            val dark = Color.rgb(Color.red(accent) / 5, Color.green(accent) / 5, Color.blue(accent) / 5)
            paint.shader = LinearGradient(0f, 0f, w, h, dark, Color.rgb(10, 10, 16), Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, w, h, paint)
            paint.shader = RadialGradient(
                w * 0.75f, h * 0.35f, w * 0.55f,
                intArrayOf(accent, Color.argb(0, Color.red(accent), Color.green(accent), Color.blue(accent))),
                null, Shader.TileMode.CLAMP
            )
            paint.alpha = 190
            c.drawRect(0f, 0f, w, h, paint)
            paint.alpha = 255
            paint.shader = null
        }
        if (slide == null) {
            paint.color = Color.WHITE
            paint.textAlign = Paint.Align.CENTER
            paint.typeface = face
            paint.textSize = h * 0.42f
            c.drawText("+", w / 2f, h * 0.55f, paint)
        }
        paint.shader = LinearGradient(
            0f, h * 0.45f, 0f, h,
            Color.argb(0, 0, 0, 0), Color.argb(215, 0, 0, 0), Shader.TileMode.CLAMP
        )
        c.drawRect(0f, 0f, w, h, paint)
        paint.shader = null

        paint.color = Color.WHITE
        paint.typeface = face
        paint.textAlign = if (slide == null) Paint.Align.CENTER else Paint.Align.LEFT
        paint.textSize = h * 0.115f
        val t = TextUtils.ellipsize(label, android.text.TextPaint(paint), w * 0.88f, TextUtils.TruncateAt.END).toString()
        c.drawText(t, if (slide == null) w / 2f else w * 0.06f, h * 0.9f, paint)
        c.restore()

        if (isFocused) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = h * 0.028f
            paint.color = Color.WHITE
            c.drawPath(path, paint)
        }
    }
}

/** App icon + name. Standalone tiles take focus themselves; grid tiles are drawn inside a GridView. */
class AppTile(
    context: Context,
    private val pm: PackageManager,
    private val standalone: Boolean
) : View(context) {

    var entry: AppEntry? = null
    var fav = false

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = android.text.TextPaint(Paint.ANTI_ALIAS_FLAG)

    init {
        if (standalone) {
            isFocusable = true
            isClickable = true
            isLongClickable = true
        }
    }

    override fun onFocusChanged(gainFocus: Boolean, direction: Int, previouslyFocusedRect: Rect?) {
        super.onFocusChanged(gainFocus, direction, previouslyFocusedRect)
        if (standalone) scaleOnFocus(this, gainFocus)
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        val e = entry ?: return
        val w = width.toFloat()
        val h = height.toFloat()
        if (standalone) {
            val r = w * 0.14f
            paint.style = Paint.Style.FILL
            paint.color = if (isFocused) Color.argb(70, 255, 255, 255) else Color.argb(28, 255, 255, 255)
            c.drawRoundRect(RectF(0f, 0f, w, h), r, r, paint)
            if (isFocused) {
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = w * 0.02f
                paint.color = Color.WHITE
                c.drawRoundRect(RectF(0f, 0f, w, h), r, r, paint)
            }
        }
        val icon = ImageCache.icon(pm, e)
        val isz = minOf(w, h * 0.7f) * 0.62f
        val ix = (w - isz) / 2f
        val iy = h * 0.12f
        paint.style = Paint.Style.FILL
        c.drawBitmap(icon, null, RectF(ix, iy, ix + isz, iy + isz), paint)

        tp.color = Color.WHITE
        tp.textSize = h * 0.115f
        tp.textAlign = Paint.Align.CENTER
        val t = TextUtils.ellipsize(e.label, tp, w * 0.9f, TextUtils.TruncateAt.END).toString()
        c.drawText(t, w / 2f, h * 0.92f, tp)

        if (fav) {
            tp.color = Color.rgb(255, 196, 40)
            tp.textSize = h * 0.16f
            tp.textAlign = Paint.Align.RIGHT
            c.drawText("★", w * 0.95f, h * 0.2f, tp)
        }
    }
}

/** Top menu button. */
class TabView(context: Context, private val label: String, private val textPx: Float) : View(context) {
    var current = false
        set(v) { field = v; invalidate() }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        isFocusable = true
        isFocusableInTouchMode = true
        isClickable = true
    }

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        paint.textSize = textPx
        paint.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        setMeasuredDimension((paint.measureText(label) + textPx * 1.8f).toInt(), (textPx * 2.3f).toInt())
    }

    override fun onFocusChanged(gainFocus: Boolean, direction: Int, previouslyFocusedRect: Rect?) {
        super.onFocusChanged(gainFocus, direction, previouslyFocusedRect)
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        paint.typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        paint.textSize = textPx
        paint.textAlign = Paint.Align.CENTER
        paint.style = Paint.Style.FILL
        val bg = when {
            isFocused -> Color.argb(240, 255, 255, 255)
            current -> Color.argb(60, 255, 255, 255)
            else -> 0
        }
        if (bg != 0) {
            paint.color = bg
            c.drawRoundRect(RectF(0f, 0f, w, h), h / 2f, h / 2f, paint)
        }
        paint.color = when {
            isFocused -> Color.rgb(12, 12, 18)
            current -> Color.WHITE
            else -> Color.argb(170, 255, 255, 255)
        }
        c.drawText(label, w / 2f, h / 2f + textPx * 0.35f, paint)
    }
}

/** A horizontal strip of focusable cards or tiles. */
class HRow(context: Context) : HorizontalScrollView(context) {
    private val inner = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL }

    init {
        isHorizontalScrollBarEnabled = false
        clipToPadding = false
        clipChildren = false
        isFillViewport = false
        addView(inner, ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
    }

    fun clear() = inner.removeAllViews()

    fun add(v: View, w: Int, h: Int, gap: Int) {
        inner.addView(v, LinearLayout.LayoutParams(w, h).apply { setMargins(0, 0, gap, 0) })
    }
}

/** One line in Settings: name on the left, current value on the right. OK changes it. */
class SettingRow(
    context: Context,
    private val title: String,
    private val value: () -> String,
    private val action: () -> Unit,
    textPx: Float
) : LinearLayout(context) {

    private val titleView = TextView(context)
    private val valueView = TextView(context)

    init {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        isFocusable = true
        isClickable = true
        val pad = (textPx * 0.7f).toInt()
        setPadding(pad * 2, pad, pad * 2, pad)
        titleView.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, textPx)
        valueView.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, textPx)
        titleView.setTextColor(Color.WHITE)
        valueView.setTextColor(Color.argb(200, 255, 255, 255))
        addView(titleView, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        addView(valueView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setOnClickListener { action(); refresh() }
        background = shape(false)
        setOnFocusChangeListener { _, f -> background = shape(f) }
        refresh()
    }

    private fun shape(focused: Boolean) = android.graphics.drawable.GradientDrawable().apply {
        cornerRadius = 24f
        setColor(if (focused) Color.argb(90, 255, 255, 255) else Color.argb(26, 255, 255, 255))
        if (focused) setStroke(3, Color.WHITE)
    }

    fun refresh() {
        titleView.text = title
        valueView.text = value()
    }
}
