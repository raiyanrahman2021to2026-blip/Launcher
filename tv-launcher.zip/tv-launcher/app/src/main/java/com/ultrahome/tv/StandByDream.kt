package com.ultrahome.tv

import android.service.dreams.DreamService

/** The system screensaver. Android starts it after the idle time set in TV Settings. */
class StandByDream : DreamService() {
    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        isInteractive = false      // any remote key or touch wakes the TV back to Home
        isFullscreen = true
        isScreenBright = true
        setContentView(ClockView(this))
    }
}
