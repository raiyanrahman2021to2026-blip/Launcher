package com.ultrahome.tv

import android.content.Context

/** Connects the web editor (EditServer) to the slide store. */
class AppHandler(private val ctx: Context, private val store: SlideStore) : EditServer.Handler {
    override fun listJson(): String = store.listJson()
    override fun addJson(body: String): Boolean = store.add(body)
    override fun delete(id: String): Boolean = store.delete(id)
    override fun move(id: String, delta: Int): Boolean = store.move(id, delta)
    override fun image(id: String): ByteArray? {
        val f = store.imageFile(id)
        return if (f.exists()) f.readBytes() else null
    }
    override fun pin(): String = store.pin()
    override fun page(): ByteArray = ctx.assets.open("editor.html").use { it.readBytes() }
}
