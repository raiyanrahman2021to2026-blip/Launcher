package com.ultrahome.tv

import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import java.io.File

/** One small, size-limited cache for banner pictures and app icons (keeps RAM low). */
object ImageCache {
    private val cache = object : LruCache<String, Bitmap>(14 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val icons = object : LruCache<String, Bitmap>(3 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val pending = HashSet<String>()
    private val ui = Handler(Looper.getMainLooper())

    fun clear() { cache.evictAll(); icons.evictAll() }

    fun drop(id: String) { cache.remove("h:$id"); cache.remove("t:$id") }

    /** Decodes with half-resolution steps, 16-bit colour: half the memory of a normal decode. */
    private fun decode(f: File, maxW: Int): Bitmap? {
        return try {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(f.path, o)
            var sample = 1
            while (o.outWidth / (sample * 2) >= maxW) sample *= 2
            val o2 = BitmapFactory.Options().apply {
                inSampleSize = sample
                inPreferredConfig = Bitmap.Config.RGB_565
            }
            BitmapFactory.decodeFile(f.path, o2)
        } catch (t: Throwable) {
            null
        }
    }

    fun thumb(store: SlideStore, id: String): Bitmap? {
        val k = "t:$id"
        cache.get(k)?.let { return it }
        val b = decode(store.imageFile(id), 480) ?: return null
        cache.put(k, b)
        return b
    }

    fun hero(id: String): Bitmap? = cache.get("h:$id")

    /** Loads a big banner picture off the UI thread, then calls [done] on the UI thread. */
    fun heroAsync(store: SlideStore, id: String, done: () -> Unit) {
        val k = "h:$id"
        if (cache.get(k) != null) return
        synchronized(pending) { if (!pending.add(k)) return }
        Thread {
            val b = decode(store.imageFile(id), 1280)
            if (b != null) cache.put(k, b)
            synchronized(pending) { pending.remove(k) }
            ui.post { done() }
        }.start()
    }

    fun icon(pm: PackageManager, e: AppEntry): Bitmap {
        icons.get(e.pkg)?.let { return it }
        val size = 96
        val b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        try {
            val d = e.ri.loadIcon(pm)
            d.setBounds(0, 0, size, size)
            d.draw(Canvas(b))
        } catch (t: Throwable) {
            // leave it empty
        }
        icons.put(e.pkg, b)
        return b
    }
}
