package com.ultrahome.tv

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.view.View

/** Colourful backgrounds drawn once into a tiny bitmap (480x270): almost no memory. */
object Backdrops {
    val NAMES = arrayOf("Aurora", "Sunset", "Ocean", "Nebula", "Candy", "Midnight")

    private class Blob(val x: Float, val y: Float, val rx: Float, val ry: Float, val color: Int, val a: Float)
    private class Look(val top: Int, val bottom: Int, val blobs: List<Blob>)

    private fun rgb(r: Int, g: Int, b: Int) = Color.rgb(r, g, b)

    private val LOOKS: List<Look> by lazy {
        listOf(
            Look(rgb(8, 12, 30), rgb(3, 4, 12), listOf(
                Blob(.25f, .15f, .38f, .32f, rgb(0, 220, 185), .60f),
                Blob(.72f, .10f, .40f, .30f, rgb(140, 70, 255), .70f),
                Blob(.50f, .55f, .45f, .22f, rgb(255, 60, 170), .30f))),
            Look(rgb(30, 10, 45), rgb(8, 5, 18), listOf(
                Blob(.50f, .25f, .45f, .30f, rgb(255, 70, 140), .70f),
                Blob(.18f, .12f, .32f, .28f, rgb(255, 150, 40), .50f),
                Blob(.85f, .20f, .30f, .30f, rgb(80, 60, 255), .55f))),
            Look(rgb(6, 20, 55), rgb(3, 8, 28), listOf(
                Blob(.30f, .20f, .42f, .30f, rgb(30, 120, 255), .70f),
                Blob(.78f, .15f, .36f, .26f, rgb(0, 220, 255), .50f),
                Blob(.55f, .60f, .42f, .22f, rgb(160, 60, 255), .35f))),
            Look(rgb(24, 8, 42), rgb(6, 3, 14), listOf(
                Blob(.20f, .18f, .38f, .30f, rgb(210, 50, 255), .65f),
                Blob(.80f, .12f, .38f, .26f, rgb(255, 80, 120), .60f),
                Blob(.55f, .45f, .30f, .16f, rgb(60, 255, 170), .28f))),
            Look(rgb(70, 30, 140), rgb(18, 12, 70), listOf(
                Blob(.20f, .20f, .40f, .32f, rgb(255, 70, 170), .80f),
                Blob(.80f, .22f, .40f, .32f, rgb(60, 200, 255), .75f),
                Blob(.55f, .72f, .50f, .30f, rgb(255, 190, 60), .40f))),
            Look(rgb(16, 20, 32), rgb(7, 9, 14), listOf(
                Blob(.50f, .05f, .70f, .50f, rgb(40, 55, 95), .60f)))
        )
    }

    fun make(index: Int): Bitmap {
        val w = 480
        val h = 270
        val look = LOOKS[index.coerceIn(0, LOOKS.size - 1)]
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.isDither = true
        p.shader = LinearGradient(0f, 0f, 0f, h.toFloat(), look.top, look.bottom, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
        for (b in look.blobs) {
            c.save()
            c.translate(b.x * w, b.y * h)
            c.scale(b.rx * w, b.ry * h)
            val col = b.color
            p.shader = RadialGradient(
                0f, 0f, 1f,
                Color.argb((b.a * 255).toInt(), Color.red(col), Color.green(col), Color.blue(col)),
                Color.argb(0, Color.red(col), Color.green(col), Color.blue(col)),
                Shader.TileMode.CLAMP
            )
            c.drawCircle(0f, 0f, 1f, p)
            c.restore()
        }
        return bmp
    }
}

class BackdropView(context: Context) : View(context) {
    private var bmp: Bitmap? = null
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG)

    fun setLook(index: Int) {
        bmp = Backdrops.make(index)
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        val b = bmp ?: return
        c.drawBitmap(b, null, RectF(0f, 0f, width.toFloat(), height.toFloat()), paint)
        c.drawColor(Color.argb(60, 0, 0, 0))   // keeps white text readable
    }
}
