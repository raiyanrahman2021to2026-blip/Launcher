package com.ultrahome.tv;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Tiny HTTP server so a phone or tablet on the same Wi-Fi can edit the TV's anime banners.
 * Pure Java (no Android classes) so it can be tested on a normal JVM.
 */
public final class EditServer {

    public interface Handler {
        String listJson();
        boolean addJson(String body);
        boolean delete(String id);
        boolean move(String id, int delta);
        byte[] image(String id);
        String pin();
        byte[] page();
    }

    private static final int MAX_BODY = 12 * 1024 * 1024;
    private final int port;
    private final Handler h;
    private final ExecutorService pool = Executors.newCachedThreadPool();
    private volatile boolean running;
    private volatile ServerSocket server;

    public EditServer(int port, Handler h) {
        this.port = port;
        this.h = h;
    }

    public synchronized void start() {
        if (running) return;
        running = true;
        Thread t = new Thread(new Runnable() {
            @Override public void run() { loop(); }
        }, "edit-server");
        t.setDaemon(true);
        t.start();
    }

    public synchronized void stop() {
        running = false;
        try { if (server != null) server.close(); } catch (IOException ignored) { }
        pool.shutdownNow();
    }

    private void loop() {
        try {
            ServerSocket ss = new ServerSocket();
            ss.setReuseAddress(true);
            ss.bind(new InetSocketAddress(port));
            server = ss;
            while (running) {
                final Socket s = ss.accept();
                pool.execute(new Runnable() {
                    @Override public void run() { handle(s); }
                });
            }
        } catch (IOException e) {
            running = false;
        }
    }

    private void handle(Socket s) {
        try {
            s.setSoTimeout(20000);
            InputStream in = new BufferedInputStream(s.getInputStream());
            OutputStream out = s.getOutputStream();
            String first = readLine(in);
            if (first == null || first.isEmpty()) { s.close(); return; }
            String[] parts = first.split(" ");
            if (parts.length < 2) { send(out, 400, "text/plain", "bad request"); s.close(); return; }
            String method = parts[0];
            String target = parts[1];

            Map<String, String> headers = new HashMap<String, String>();
            String line;
            while ((line = readLine(in)) != null && !line.isEmpty()) {
                int c = line.indexOf(':');
                if (c > 0) headers.put(line.substring(0, c).trim().toLowerCase(), line.substring(c + 1).trim());
            }
            int len = 0;
            String cl = headers.get("content-length");
            if (cl != null) {
                try { len = Integer.parseInt(cl); } catch (NumberFormatException e) { len = -1; }
            }
            if (len < 0 || len > MAX_BODY) { send(out, 413, "text/plain", "too large"); s.close(); return; }
            byte[] body = new byte[len];
            int got = 0;
            while (got < len) {
                int r = in.read(body, got, len - got);
                if (r < 0) break;
                got += r;
            }

            String path = target;
            String query = "";
            int q = target.indexOf('?');
            if (q >= 0) { path = target.substring(0, q); query = target.substring(q + 1); }

            route(out, method, path, query, headers, body);
            out.flush();
        } catch (Exception ignored) {
        } finally {
            try { s.close(); } catch (IOException ignored) { }
        }
    }

    private void route(OutputStream out, String method, String path, String query,
                       Map<String, String> headers, byte[] body) throws IOException {
        if (method.equals("GET") && (path.equals("/") || path.equals("/index.html"))) {
            sendBytes(out, 200, "text/html; charset=utf-8", h.page());
            return;
        }
        if (method.equals("GET") && path.startsWith("/img/")) {
            String id = path.substring(5);
            if (!safeId(id)) { send(out, 404, "text/plain", "not found"); return; }
            byte[] img = h.image(id);
            if (img == null) { send(out, 404, "text/plain", "not found"); return; }
            sendBytes(out, 200, "image/jpeg", img);
            return;
        }
        if (path.startsWith("/api/")) {
            String given = headers.get("x-pin");
            if (given == null || !MessageDigest.isEqual(
                    given.getBytes(StandardCharsets.UTF_8), h.pin().getBytes(StandardCharsets.UTF_8))) {
                send(out, 401, "application/json", "{\"error\":\"pin\"}");
                return;
            }
            if (method.equals("GET") && path.equals("/api/slides")) {
                send(out, 200, "application/json", h.listJson());
                return;
            }
            if (method.equals("POST") && path.equals("/api/slides")) {
                boolean ok = h.addJson(new String(body, StandardCharsets.UTF_8));
                send(out, ok ? 200 : 400, "application/json", ok ? "{\"ok\":true}" : "{\"error\":\"invalid\"}");
                return;
            }
            if (method.equals("DELETE") && path.startsWith("/api/slides/")) {
                String id = path.substring("/api/slides/".length());
                if (!safeId(id)) { send(out, 404, "application/json", "{\"error\":\"id\"}"); return; }
                boolean ok = h.delete(id);
                send(out, ok ? 200 : 404, "application/json", ok ? "{\"ok\":true}" : "{\"error\":\"missing\"}");
                return;
            }
            if (method.equals("POST") && path.startsWith("/api/slides/") && path.endsWith("/move")) {
                String id = path.substring("/api/slides/".length(), path.length() - "/move".length());
                int d = query.contains("d=-1") ? -1 : 1;
                if (!safeId(id)) { send(out, 404, "application/json", "{\"error\":\"id\"}"); return; }
                boolean ok = h.move(id, d);
                send(out, ok ? 200 : 404, "application/json", ok ? "{\"ok\":true}" : "{\"error\":\"missing\"}");
                return;
            }
        }
        send(out, 404, "text/plain", "not found");
    }

    private static boolean safeId(String id) {
        if (id.isEmpty() || id.length() > 40) return false;
        for (int i = 0; i < id.length(); i++) {
            char c = id.charAt(i);
            if (!((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9'))) return false;
        }
        return true;
    }

    private static String readLine(InputStream in) throws IOException {
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        int c;
        while ((c = in.read()) != -1) {
            if (c == '\n') break;
            if (c != '\r') b.write(c);
            if (b.size() > 8192) throw new IOException("line too long");
        }
        if (c == -1 && b.size() == 0) return null;
        return new String(b.toByteArray(), StandardCharsets.UTF_8);
    }

    private static void send(OutputStream out, int code, String type, String body) throws IOException {
        sendBytes(out, code, type.indexOf("charset") >= 0 ? type : type + "; charset=utf-8",
                body.getBytes(StandardCharsets.UTF_8));
    }

    private static void sendBytes(OutputStream out, int code, String type, byte[] body) throws IOException {
        String status;
        switch (code) {
            case 200: status = "OK"; break;
            case 400: status = "Bad Request"; break;
            case 401: status = "Unauthorized"; break;
            case 404: status = "Not Found"; break;
            case 413: status = "Payload Too Large"; break;
            default: status = "Error";
        }
        String head = "HTTP/1.1 " + code + " " + status + "\r\n"
                + "Content-Type: " + type + "\r\n"
                + "Content-Length: " + body.length + "\r\n"
                + "Cache-Control: no-store\r\n"
                + "Connection: close\r\n\r\n";
        out.write(head.getBytes(StandardCharsets.UTF_8));
        out.write(body);
    }
}
