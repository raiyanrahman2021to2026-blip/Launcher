package com.ultrahome.tv

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import java.net.Inet4Address
import java.net.NetworkInterface
import java.text.SimpleDateFormat
import java.util.Collections
import java.util.Date
import java.util.Locale

/**
 * A TV launcher with Home, Apps, Anime, Movies and Settings.
 * Kept light on memory: custom-drawn views, tiny cached backgrounds, 16-bit pictures,
 * everything pauses when you leave the launcher.
 */
class HomeActivity : Activity(), Host {

    private lateinit var storeImpl: SlideStore
    override val store: SlideStore get() = storeImpl
    private var appList: List<AppEntry> = emptyList()
    override val apps: List<AppEntry> get() = appList

    private lateinit var root: FrameLayout
    private lateinit var container: FrameLayout
    private lateinit var backdrop: BackdropView
    private lateinit var clockText: TextView
    private val tabs = ArrayList<TabView>()
    private val pages = ArrayList<Page>()
    private var current = 0
    private var server: EditServer? = null
    private var overlay: ClockView? = null
    private var seenRevision = -1
    private val ui = Handler(Looper.getMainLooper())
    private val idleRun = Runnable { showStandBy() }

    private val tick = object : Runnable {
        override fun run() {
            clockText.text = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())
            val rev = SlideStore.revision.get()
            if (rev != seenRevision) {
                seenRevision = rev
                pages[current].refresh()
            }
            ui.postDelayed(this, 2000L)
        }
    }

    // ------------------------------------------------------------------ setup

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        storeImpl = SlideStore(this)

        val sw = resources.displayMetrics.widthPixels
        val sh = resources.displayMetrics.heightPixels

        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        backdrop = BackdropView(this).apply { setLook(UiPrefs.look(this@HomeActivity)) }
        root.addView(backdrop, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val column = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(column, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // top bar: tabs in the middle, clock on the right
        val bar = FrameLayout(this)
        val tabRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        bar.addView(tabRow, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
        clockText = TextView(this).apply {
            setTextSize(TypedValue.COMPLEX_UNIT_PX, sh * 0.034f)
            setTextColor(Color.argb(230, 255, 255, 255))
        }
        bar.addView(clockText, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.END or Gravity.CENTER_VERTICAL).apply { rightMargin = (sw * 0.04f).toInt() })
        column.addView(bar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (sh * 0.11f).toInt()))

        container = FrameLayout(this)
        column.addView(container, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        pages.add(HomePage(this, this))
        pages.add(AppsPage(this, this))
        pages.add(ContentPage(this, this, "anime", "anime"))
        pages.add(ContentPage(this, this, "movie", "movies"))
        pages.add(SettingsPage(this, this))
        val names = arrayOf("Home", "Apps", "Anime", "Movies", "Settings")

        for (i in pages.indices) {
            container.addView(pages[i].view, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            pages[i].view.visibility = android.view.View.GONE

            val t = TabView(this, names[i], sh * 0.026f)
            t.setOnFocusChangeListener { _, has -> if (has) showPage(i) }
            t.setOnClickListener { pages[i].firstFocus()?.requestFocus() }
            tabs.add(t)
            tabRow.addView(t, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                setMargins((sw * 0.004f).toInt(), 0, (sw * 0.004f).toInt(), 0)
            })
        }
        setContentView(root)
        showPage(0)
    }

    override fun onResume() {
        super.onResume()
        appList = loadApps()
        server = EditServer(8080, AppHandler(applicationContext, storeImpl)).also { it.start() }
        seenRevision = -1
        ui.removeCallbacks(tick)
        ui.post(tick)
        resetIdle()
        pages[current].firstFocus()?.requestFocus()
    }

    override fun onPause() {
        ui.removeCallbacks(tick)
        ui.removeCallbacks(idleRun)
        hideStandBy()
        server?.stop()                 // nothing runs in the background while you watch something
        server = null
        super.onPause()
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= android.content.ComponentCallbacks2.TRIM_MEMORY_BACKGROUND) ImageCache.clear()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        hideStandBy()
        showPage(0)
        pages[0].firstFocus()?.requestFocus()
    }

    private fun showPage(i: Int) {
        if (i == current && pages[i].view.visibility == android.view.View.VISIBLE) return
        pages[current].view.visibility = android.view.View.GONE
        pages[current].onHide()
        current = i
        pages[i].view.visibility = android.view.View.VISIBLE
        pages[i].onShow()
        for (k in tabs.indices) tabs[k].current = (k == i)
    }

    // ------------------------------------------------------------------ keys, idle, StandBy

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (overlay != null) {
            if (event.action == KeyEvent.ACTION_UP) hideStandBy()
            return true                                  // the first key only wakes Home
        }
        if (event.action == KeyEvent.ACTION_DOWN) resetIdle()
        return super.dispatchKeyEvent(event)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (overlay != null) hideStandBy()
        else if (current != 0) {
            showPage(0)
            pages[0].firstFocus()?.requestFocus()
        }
        // on Home itself, Back does nothing
    }

    private fun resetIdle() {
        ui.removeCallbacks(idleRun)
        val minutes = ClockPrefs.read(this).idle
        if (minutes > 0) ui.postDelayed(idleRun, minutes * 60_000L)
    }

    override fun showStandBy() {
        if (overlay != null) return
        val v = ClockView(this)
        overlay = v
        root.addView(v, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
    }

    private fun hideStandBy() {
        overlay?.let { root.removeView(it) }
        overlay = null
        resetIdle()
    }

    // ------------------------------------------------------------------ Host

    override fun launch(intent: Intent) {
        try { startActivity(intent) } catch (e: Exception) { /* app was removed */ }
    }

    override fun playTrailer(s: Slide) {
        val q = if (s.query.isNotEmpty()) s.query else s.title + " official trailer"
        try {
            startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q)))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Exception) {
            // no app on this TV can open links
        }
    }

    override fun openTab(i: Int) {
        showPage(i)
        tabs[i].requestFocus()
    }

    override fun applyLook() {
        backdrop.setLook(UiPrefs.look(this))
    }

    override fun changed() {
        pages[current].refresh()
    }

    override fun editorHint(): String {
        val ip = localIp() ?: return "Connect the TV to Wi-Fi first"
        return "http://$ip:8080   PIN ${storeImpl.pin()}"
    }

    override fun favorites(): List<AppEntry> {
        val byPkg = appList.associateBy { it.pkg }
        if (UiPrefs.hasChosenFavorites(this)) return UiPrefs.favorites(this).mapNotNull { byPkg[it] }
        val popular = listOf(
            "com.google.android.youtube.tv", "com.netflix.ninja", "com.amazon.amazonvideo.livingroom",
            "com.disney.disneyplus", "com.google.android.youtube.tvmusic", "com.spotify.tv.android"
        )
        val picks = popular.mapNotNull { byPkg[it] }
        return if (picks.isNotEmpty()) picks else appList.take(6)
    }

    private fun localIp(): String? {
        try {
            val ifs = NetworkInterface.getNetworkInterfaces() ?: return null
            for (ni in Collections.list(ifs)) {
                if (!ni.isUp || ni.isLoopback) continue
                for (a in Collections.list(ni.inetAddresses)) {
                    if (a is Inet4Address && !a.isLoopbackAddress) return a.hostAddress
                }
            }
        } catch (e: Exception) {
            // no network
        }
        return null
    }

    private fun loadApps(): List<AppEntry> {
        val pm = packageManager
        fun query(cat: String) = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(cat), 0)
        return (query(Intent.CATEGORY_LEANBACK_LAUNCHER) + query(Intent.CATEGORY_LAUNCHER))
            .filter { it.activityInfo.packageName != packageName }
            .distinctBy { it.activityInfo.packageName }
            .mapNotNull { ri ->
                val pkg = ri.activityInfo.packageName
                val launch = pm.getLeanbackLaunchIntentForPackage(pkg)
                    ?: pm.getLaunchIntentForPackage(pkg)
                    ?: return@mapNotNull null
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                AppEntry(ri.loadLabel(pm).toString(), pkg, launch, ri)
            }
            .sortedBy { it.label.lowercase() }
    }
}
