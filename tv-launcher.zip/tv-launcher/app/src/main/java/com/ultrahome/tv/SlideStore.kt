package com.ultrahome.tv

import android.content.Context
import android.graphics.Color
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Random
import java.util.concurrent.atomic.AtomicInteger

data class Slide(
    val id: String,
    val title: String,
    val tagline: String,
    val kicker: String,
    val query: String,
    val accent: Int,
    val hasImage: Boolean,
    val cat: String = "anime"
)

/** The list of banners (JSON in SharedPreferences) and their pictures (files). */
class SlideStore(ctx: Context) {

    companion object {
        /** Bumped on every change so the home screen knows to reload. */
        val revision = AtomicInteger(0)
        private const val MAX_SLIDES = 20
        private const val MAX_IMAGE_BYTES = 8 * 1024 * 1024
    }

    private val prefs = ctx.getSharedPreferences("anime", Context.MODE_PRIVATE)
    private val dir = File(ctx.filesDir, "anime").apply { mkdirs() }
    private val lock = Any()

    fun imageFile(id: String): File = File(dir, "$id.jpg")

    fun pin(): String = synchronized(lock) {
        var p = prefs.getString("pin", null)
        if (p == null) {
            p = (1000 + Random().nextInt(9000)).toString()
            prefs.edit().putString("pin", p).apply()
        }
        p
    }

    private fun defaults(): JSONArray {
        fun one(id: String, title: String, kicker: String, tag: String, accent: String) =
            JSONObject().put("id", id).put("title", title).put("kicker", kicker).put("tagline", tag)
                .put("query", "$title official trailer").put("accent", accent)
        return JSONArray()
            .put(one("d1", "Dragon Ball", "Action / Fantasy", "Power with no ceiling.", "#ffb020"))
            .put(one("d2", "Jujutsu Kaisen", "Dark Fantasy", "Curses are real. So is the fight.", "#b388ff"))
            .put(one("d3", "Attack on Titan", "Drama / Action", "Humanity on the edge.", "#7fd1ff"))
    }

    private fun readArray(): JSONArray {
        val s = prefs.getString("slides", null)
        if (s != null) {
            try { return JSONArray(s) } catch (e: Exception) { /* fall through to defaults */ }
        }
        return defaults()
    }

    private fun save(a: JSONArray) {
        prefs.edit().putString("slides", a.toString()).apply()
        revision.incrementAndGet()
    }

    private fun color(s: String): Int =
        try { Color.parseColor(s) } catch (e: Exception) { 0xFFFFB020.toInt() }

    fun list(): List<Slide> = synchronized(lock) {
        val a = readArray()
        val out = ArrayList<Slide>()
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            val id = o.optString("id")
            if (id.isEmpty()) continue
            out.add(
                Slide(
                    id, o.optString("title"), o.optString("tagline"), o.optString("kicker"),
                    o.optString("query"), color(o.optString("accent")), imageFile(id).exists(),
                    if (o.optString("cat") == "movie") "movie" else "anime"
                )
            )
        }
        out
    }

    fun listJson(): String = synchronized(lock) {
        val a = readArray()
        val out = JSONArray()
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            val id = o.optString("id")
            out.put(
                JSONObject().put("id", id).put("title", o.optString("title"))
                    .put("tagline", o.optString("tagline")).put("kicker", o.optString("kicker"))
                    .put("query", o.optString("query")).put("accent", o.optString("accent")).put("cat", o.optString("cat", "anime"))
                    .put("hasImage", imageFile(id).exists())
            )
        }
        out.toString()
    }

    fun add(body: String): Boolean = synchronized(lock) {
        try {
            val j = JSONObject(body)
            val title = j.optString("title").trim().take(40)
            if (title.isEmpty()) return@synchronized false
            val a = readArray()
            if (a.length() >= MAX_SLIDES) return@synchronized false

            val accentIn = j.optString("accent")
            val accent = if (Regex("^#[0-9a-fA-F]{6}$").matches(accentIn)) accentIn else "#ffb020"
            val id = java.lang.Long.toString(System.currentTimeMillis(), 36)

            val image = j.optString("image")
            if (image.startsWith("data:image")) {
                val comma = image.indexOf(',')
                if (comma < 0) return@synchronized false
                val bytes = Base64.decode(image.substring(comma + 1), Base64.DEFAULT)
                if (bytes.size > MAX_IMAGE_BYTES) return@synchronized false
                imageFile(id).writeBytes(bytes)
            }

            val query = j.optString("query").trim().take(120).ifEmpty { "$title official trailer" }
            a.put(
                JSONObject().put("id", id).put("title", title)
                    .put("kicker", j.optString("kicker").trim().take(30))
                    .put("tagline", j.optString("tagline").trim().take(80))
                    .put("query", query).put("accent", accent)
                    .put("cat", if (j.optString("cat") == "movie") "movie" else "anime")
            )
            save(a)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun delete(id: String): Boolean = synchronized(lock) {
        val a = readArray()
        val out = JSONArray()
        var found = false
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            if (o.optString("id") == id) { found = true; continue }
            out.put(o)
        }
        if (found) {
            imageFile(id).delete()
            ImageCache.drop(id)
            save(out)
        }
        found
    }

    /** Back to the three starter banners; deletes all added pictures. */
    fun reset() = synchronized(lock) {
        dir.listFiles()?.forEach { it.delete() }
        ImageCache.clear()
        prefs.edit().remove("slides").apply()
        revision.incrementAndGet()
    }

    fun move(id: String, delta: Int): Boolean = synchronized(lock) {
        val a = readArray()
        val items = ArrayList<JSONObject>()
        for (i in 0 until a.length()) a.optJSONObject(i)?.let { items.add(it) }
        val idx = items.indexOfFirst { it.optString("id") == id }
        if (idx < 0) return@synchronized false
        val to = (idx + delta).coerceIn(0, items.size - 1)
        val o = items.removeAt(idx)
        items.add(to, o)
        val out = JSONArray()
        for (x in items) out.put(x)
        save(out)
        true
    }
}
