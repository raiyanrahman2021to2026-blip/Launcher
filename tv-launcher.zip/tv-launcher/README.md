# TV launcher

Ek hi app mein: Home, Apps, Anime, Movies, Settings + iPhone-style StandBy clock.

## Sections (upar ka menu, remote ke LEFT/RIGHT se)
- **Home**: bada rounded banner (Apple TV jaisa), neeche "My apps", "Anime", "Movies" ki rows.
- **Apps**: tumhare saare apps. OK = kholo. OK dabaye rakho (hold) = Home mein add / hatao (★ nishaan).
- **Anime** / **Movies**: bada banner + cards. OK = official trailer (YouTube) khulta hai.
- **Settings**: StandBy clock ki saari customization, background (6 rang), banners ka editor address.

## StandBy clock (Settings mein)
Style (Digital, Analog, Clock + calendar, Bold stack), Colour (7), 12/24-hour, Seconds, Night (red),
Start after (Off, 1, 2, 5, 10, 15 min), Preview now. Ye sirf Home par chalti hai: Home par 5 minute
(ya jo chuno) remote na chalao to clock aati hai, koi bhi button dabao to wapas.
Ye bhi ek system screensaver ke roop mein TV Settings > Screen saver mein "StandBy Clock" ke naam se dikhegi (optional).

## Anime / movie banners badalna (tablet ya phone se)
1. Settings > "Edit from your phone" mein address aur PIN dikhta hai (Anime/Movies page ke neeche bhi), jaise `http://192.168.1.20:8080  PIN 1234`.
2. Tablet same WiFi par, browser mein wo address kholo, PIN daalo.
3. Section (Anime ya Movie), naam, tagline, rang aur apni photo chuno > Add to TV. Up / Down / Delete se order badlo.
Photo wahi lagao jo tumhare paas hai ya jise use karne ka haq hai.

## RAM kam kaise rakhi
- Koi library nahi, sab kuch hath se draw hota hai.
- Background sirf 480x270 ki ek chhoti image, bade pictures 16-bit mein aur sirf ek chhote cache mein.
- Icons 96 px, cache limit 3 MB; banners cache limit 14 MB.
- Launcher se bahar jate hi (koi app kholne par) timers aur editor server band ho jate hain.
- Memory kam hone par cache apne aap khali.

## APK banana (GitHub, ~5 min)
1. github.com par apna naya repo banao (naam: ultra-home, Public).
2. Zip extract karke saari files upload karo (Add file > Upload files).
   `.github` hidden folder upload na ho to: Add file > Create new file > naam `.github/workflows/build.yml`
   aur `BUILD-WORKFLOW.txt` ka content paste karo.
3. Actions > Build APK > hara tick > Artifacts > Launcher-apk > download > extract > `app-debug.apk`.

## TV par lagana
APK ko "Send Files to TV" se TV par bhejo, Install karo (Install unknown apps allow),
HOME dabao > "Launcher" naam wala app chuno > Always. Purane launcher par wapas: TV Settings > Apps > Launcher > Clear defaults.

## Jo abhi nahi hai
- Asli anime ya movie ke characters/photos app mein built-in nahi hain (copyright); tum apni photos editor se lagate ho.
- Movies/anime ke liye sirf trailer YouTube mein khulta hai; poori video app ke andar nahi chalti.
